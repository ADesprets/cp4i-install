package com.ibm.ad.demo.rest.data.generators;

public class ProductGenerator {

}
